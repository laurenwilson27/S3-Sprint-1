UPDATE Schedule
SET MaxTickets = 50;


select * from schedule
