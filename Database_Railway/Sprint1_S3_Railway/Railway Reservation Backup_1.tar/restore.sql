--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Railway Reservation ";
--
-- Name: Railway Reservation ; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Railway Reservation " WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "Railway Reservation " OWNER TO postgres;

\connect -reuse-previous=on "dbname='Railway Reservation '"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "Railway Reservation "; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "Railway Reservation " IS 'A DB of a typical railway operation.';


--
-- Name: booking_param_check(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.booking_param_check() RETURNS TABLE(passenger_id integer, train_id character varying, route_id integer, departuredate date)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        p.passenger_id,
        sch.train_id,
        sch.route_id,
        sch.departuredate
    FROM 
        public.ticket t
    INNER JOIN public.passenger p ON t.passenger_id = p.passenger_id
    INNER JOIN public.schedule sch ON t.schedule_id = sch.schedule_id
    ORDER BY sch.route_id ASC;
END;
$$;


ALTER FUNCTION public.booking_param_check() OWNER TO postgres;

--
-- Name: cancel_ticket_confirm_waiting(integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.cancel_ticket_confirm_waiting(IN p_ticket_id integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_schedule_id INTEGER;
    v_train_id VARCHAR;
    v_next_waiting_ticket_id INTEGER;
    v_current_status VARCHAR;
    v_waiting_tickets INTEGER;
BEGIN
    -- Retrieve the schedule_id, train_id, and current booking status for the ticket
    SELECT s.schedule_id, s.train_id, t.bookingstatus INTO v_schedule_id, v_train_id, v_current_status
    FROM ticket t
    JOIN schedule s ON t.schedule_id = s.schedule_id
    WHERE t.ticket_id = p_ticket_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Ticket with ID % does not exist.', p_ticket_id;
    ELSIF v_current_status = 'CANCELLED' THEN
        RAISE NOTICE 'Ticket with ID % is already cancelled.', p_ticket_id;
    ELSE
        -- Change the ticket's status to 'CANCELLED'
        UPDATE ticket
        SET bookingstatus = 'CANCELLED'
        WHERE ticket_id = p_ticket_id;

        -- Find the first waiting ticket for the same schedule
        SELECT ticket_id INTO v_next_waiting_ticket_id
        FROM ticket
        WHERE schedule_id = v_schedule_id
          AND bookingstatus = 'WAITING'
        ORDER BY ticket_id
        LIMIT 1;

        -- If a waiting ticket is found, change its status to 'CONFIRMED'
        IF v_next_waiting_ticket_id IS NOT NULL THEN
            UPDATE ticket
            SET bookingstatus = 'CONFIRMED'
            WHERE ticket_id = v_next_waiting_ticket_id;
            
            -- Optionally, update the schedule's waiting tickets if necessary
        IF v_waiting_tickets > 0 THEN
                UPDATE schedule
                SET waitingtickets = waitingtickets - 1
                WHERE schedule_id = v_schedule_id;
            END IF;
        END IF;
        -- Output the result to the user
        RAISE NOTICE 'Ticket with ID % has been cancelled.', p_ticket_id;
        IF v_next_waiting_ticket_id IS NOT NULL THEN
            RAISE NOTICE 'Waiting ticket with ID % has been confirmed.', v_next_waiting_ticket_id;
        END IF;
    END IF;
END;
$$;


ALTER PROCEDURE public.cancel_ticket_confirm_waiting(IN p_ticket_id integer) OWNER TO postgres;

--
-- Name: cancel_ticket_details(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cancel_ticket_details() RETURNS TABLE(ticket_id integer, schedule_id integer, booking_status character varying, seatnum integer, departure_date date, departure_time character varying, total_seats_booked integer, waiting_tickets integer, train_id character varying, train_name character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        t.ticket_id,
        t.schedule_id,
        t.bookingstatus AS "Booking Status",
        t.seatnum,
        s.departuredate AS "Departure Date",
        s.departuretime AS "Departure Time",
        s.totalseatsbooked AS "Total Seats Booked",
        s.waitingtickets AS "Waiting Tickets",
        tr.train_id,
        tr.trainname
    FROM
        public.ticket t
    JOIN
        public.schedule s ON t.schedule_id = s.schedule_id
    JOIN
        public.train tr ON s.train_id = tr.train_id
    ORDER BY
        t.ticket_id ASC;
END;
$$;


ALTER FUNCTION public.cancel_ticket_details() OWNER TO postgres;

--
-- Name: get_employee_details(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_employee_details(p_station_id character varying DEFAULT NULL::character varying, p_employee_id integer DEFAULT NULL::integer) RETURNS TABLE(employee_id integer, employee_name character varying, role character varying, department character varying, hiredate date, salary money, birthdate date, employee_phone character varying, street character varying, city character varying, province character varying, postalcode character varying, country character varying, station_id character varying, stationname character varying, station_city character varying, operationhours character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY 
    SELECT
        e.employee_id,
        e.name,
        e.role,
        e.department,
        e.hiredate,
        e.salary,
        e.birthdate,
        e.phone,
        a.street,
        a.city,
        a.province,
        a.postalcode,
        a.country,
        st.station_id,
        st.stationname,
        st.city,
        st.operationhours
    FROM
        public.employee e
    INNER JOIN
        public.address a ON e.address_id = a.address_id
    INNER JOIN
        public.station st ON e.station_id = st.station_id
    WHERE
        (p_station_id IS NULL OR st.station_id = p_station_id)
        AND
        (p_employee_id IS NULL OR e.employee_id = p_employee_id);
END;
$$;


ALTER FUNCTION public.get_employee_details(p_station_id character varying, p_employee_id integer) OWNER TO postgres;

--
-- Name: get_ticket_details(character varying, integer, integer, date); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_ticket_details(p_train_id character varying, p_route_id integer, p_passenger_id integer, p_departure_date date) RETURNS TABLE(departure_date date, train_id character varying, schedule_id integer, route_id integer, passenger_id integer, totalseatsbooked integer, ticket_id integer, seat_num integer, waiting_tickets integer, max_tickets integer, booking_status character varying, schedule_status character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sch.departureDate, 
		sch.train_id,
        sch.schedule_id,
		sch.route_id,
		tkt.passenger_id,
		sch.totalSeatsBooked,
        tkt.ticket_id,
		tkt.seatnum,
		sch.waitingTickets,
		sch.maxTickets,
        tkt.bookingstatus,
		sch.status
    FROM 
        ticket tkt
    JOIN schedule sch ON tkt.schedule_id = sch.schedule_id
    WHERE 
        (p_train_id IS NULL OR sch.train_id = p_train_id)
        AND (p_route_id IS NULL OR sch.route_id = p_route_id)
        AND (p_passenger_id IS NULL OR tkt.passenger_id = p_passenger_id)
        AND (p_departure_date IS NULL OR sch.departuredate = p_departure_date)
		ORDER BY 
        tkt.seatnum DESC;
END;
$$;


ALTER FUNCTION public.get_ticket_details(p_train_id character varying, p_route_id integer, p_passenger_id integer, p_departure_date date) OWNER TO postgres;

--
-- Name: get_ticket_details_by_name(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_ticket_details_by_name(partial_name character varying) RETURNS TABLE(ticket_id integer, schedule_id integer, route_id integer, passenger_id integer, passenger_name character varying, seatnum integer, booking_status character varying, departure_date date, departure_time character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY 
    SELECT 
        t.ticket_id,
        t.schedule_id,
        s.route_id,
        p.passenger_id,
        p.name,
        t.seatnum,
        t.bookingstatus,
        s.departuredate,
        s.departuretime
    FROM 
        ticket t
    JOIN 
        passenger p ON t.passenger_id = p.passenger_id
    JOIN 
        schedule s ON t.schedule_id = s.schedule_id
    WHERE 
        p.name ILIKE '%' || partial_name || '%';
END;
$$;


ALTER FUNCTION public.get_ticket_details_by_name(partial_name character varying) OWNER TO postgres;

--
-- Name: get_train_and_route_details(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_train_and_route_details(p_train_id character varying, p_route_id integer) RETURNS TABLE(route_id integer, distance character varying, duration character varying, train_id character varying, trainname character varying, weightcap integer, numberofcars integer, accelerationrate character varying, decelerationrate character varying, maxspeed character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY 
    SELECT
        r.route_id,
        r.distance,
        r.duration,
        tr.train_id,
        tr.trainname,
        ts.weightcap,
        ts.numberofcars,
        ts.accelerationrate,
        ts.decelerationrate,
        ts.maxspeed
    FROM
        public.train AS tr
    JOIN
        public.trainspecs AS ts ON tr.train_id = ts.train_id
    JOIN
        public.schedule AS s ON tr.train_id = s.train_id
    JOIN
        public.route AS r ON s.route_id = r.route_id
    WHERE
        tr.train_id = p_train_id AND
        r.route_id = p_route_id
    ORDER BY
        r.route_id ASC;
END;
$$;


ALTER FUNCTION public.get_train_and_route_details(p_train_id character varying, p_route_id integer) OWNER TO postgres;

--
-- Name: get_train_maintenance_details(character varying, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_train_maintenance_details(p_train_id character varying DEFAULT NULL::character varying, p_maintenance_id integer DEFAULT NULL::integer) RETURNS TABLE(maintenance_id integer, trainmaintenance_id integer, train_id character varying, trainname character varying, servicedate date, nextservicedate date, reported_issues character varying, maintenance_details text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY 
    SELECT
	    tm.Maintenance_ID,
        tm.TrainMaintenance_ID,
        tr.train_ID,
        tr.trainname,
        tm.ServiceDate,
        tm.NextServiceDate,
        tm.IssueDetails AS "Reported_Issues", -- Ensure this is VARCHAR(255)
        m.details AS "Maintenance_Details"
    FROM
        public.train_maintenance tm
    JOIN
        public.train tr ON tm.Train_ID = tr.train_id
    JOIN
        public.maintenance m ON tm.Maintenance_ID = m.maintenance_id
    WHERE
        (p_train_id IS NULL OR tr.train_id = p_train_id)
        AND
        (p_maintenance_id IS NULL OR tm.Maintenance_ID = p_maintenance_id)
    ORDER BY
        tm.ServiceDate DESC;
END;
$$;


ALTER FUNCTION public.get_train_maintenance_details(p_train_id character varying, p_maintenance_id integer) OWNER TO postgres;

--
-- Name: insert_new_tkt(character varying, integer, integer, date); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insert_new_tkt(IN p_train_id character varying, IN p_route_id integer, IN p_passenger_id integer, IN p_departuredate date)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_schedule_id INTEGER;
    v_totalseatsbooked INT;
    v_waitingtickets INT;
    v_ticket_id INT;
    v_seatnum INT; -- Added to store the next available seat number
    v_status VARCHAR;
BEGIN
    -- Validate the train number and booking date
    SELECT schedule_id, totalseatsbooked, waitingtickets INTO v_schedule_id, v_totalseatsbooked, v_waitingtickets
    FROM schedule
    WHERE train_id = p_train_id 
      AND route_id = p_route_id 
      AND departuredate = p_departuredate
      AND departuredate BETWEEN current_date AND current_date + interval '7 days';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'No schedule found for this train and date within the permitted booking window.';
    END IF;
    
    SELECT COALESCE(MAX(seatnum), 0) + 1 INTO v_seatnum
    FROM ticket
    WHERE schedule_id = v_schedule_id;
    
    IF v_totalseatsbooked < 56 THEN
        -- Update the schedule: increment TotalSeatsBooked
        UPDATE schedule
        SET totalseatsbooked = totalseatsbooked + 1,
            waitingtickets = CASE
                                WHEN totalseatsbooked >= 50 AND totalseatsbooked < 55 THEN totalseatsbooked - 49
                                ELSE 0
                             END,
            status = CASE
                        WHEN totalseatsbooked >= 49 AND totalseatsbooked < 55 THEN 'FULL'
                        ELSE 'ON TIME'
                     END
        WHERE schedule_id = v_schedule_id
        RETURNING totalseatsbooked INTO v_totalseatsbooked;
        
        -- Determine the booking status based on the updated total seats booked
        IF v_totalseatsbooked <= 50 THEN
            v_status := 'CONFIRMED';
        ELSIF v_totalseatsbooked BETWEEN 51 AND 55 THEN
            v_status := 'WAITING';
        ELSE
            v_status := 'FULL';
        END IF;
        
        -- Calculate the ticket_id for the new ticket
        v_ticket_id := (p_route_id * 100000) + (p_passenger_id * 100) + v_totalseatsbooked;
        
        -- Insert the new ticket with the determined seat number and status
        INSERT INTO ticket(ticket_id, schedule_id, passenger_id, seatnum, bookingstatus, bookingdate)
        VALUES (v_ticket_id, v_schedule_id, p_passenger_id, v_seatnum, v_status, current_date);

        -- Output the ticket ID to the user
        RAISE NOTICE 'Ticket booked successfully with status %. Ticket ID: %, Seat Number: %', v_status, v_ticket_id, v_seatnum;
    ELSE
        RAISE EXCEPTION 'Unable to book ticket as the train is fully booked.';
    END IF;
END;
$$;


ALTER PROCEDURE public.insert_new_tkt(IN p_train_id character varying, IN p_route_id integer, IN p_passenger_id integer, IN p_departuredate date) OWNER TO postgres;

--
-- Name: latest_ticket_info(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.latest_ticket_info(p_route_id integer, p_passenger_id integer) RETURNS TABLE(schedule_id integer, departuredate date, status character varying, maxtickets integer, totalseatsbooked integer, waitingtickets integer, passenger_id integer, ticket_id integer, ticketnum integer, bookingstatus character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY 
    SELECT 
		sch.train_id,
        sch.schedule_id,
		tkt.passenger_id,
        sch.departureDate, 
        sch.status,
        sch.maxTickets,
		sch.waitingTickets,
        sch.totalSeatsBooked,
		tkt.ticketnum,
		tkt.ticket_id,
        tkt.BookingStatus
    FROM 
        schedule sch
    JOIN 
        ticket tkt ON sch.schedule_id = tkt.schedule_id
    WHERE 
        tkt.schedule_id = p_route_id AND tkt.passenger_id = p_passenger_id
    ORDER BY 
        tkt.ticket_id DESC
    LIMIT 1;
END;
$$;


ALTER FUNCTION public.latest_ticket_info(p_route_id integer, p_passenger_id integer) OWNER TO postgres;

--
-- Name: random_platform_num(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.random_platform_num() RETURNS integer
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN (floor(random() * 10) + 1)::INTEGER;
END;
$$;


ALTER FUNCTION public.random_platform_num() OWNER TO postgres;

--
-- Name: reset_and_show_booking_status(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.reset_and_show_booking_status()
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Resetting demonstration data
    UPDATE schedule
    SET maxtickets = 50, totalseatsbooked = 0, waitingtickets = 0,
        bookingopendate = current_date,
		bookingcloseddate = current_date + 7,
        departuredate = current_date + interval '7 days';
-- Allowing these to be updateable and consistent with todays date are again
--to simplify issues and expedite testing.

-- it is understood the dates would not be allowed to be set with such 
--formulaic consistency in real applications. If that were the case,
--real dates and times would have to be maintained in the DB throughout its use.
    
    DELETE  FROM ticket WHERE ticket_id > 250;
    
  UPDATE ticket
SET bookingstatus = 'UNCONFIRMED',
    bookingdate = current_date + interval '3 days',
	seatnum = 0;
    
    -- The notice to indicate procedure completion
    RAISE NOTICE 'Reset and display operation completed. Please run the SELECT query to view the updated booking status.';
END;
$$;


ALTER PROCEDURE public.reset_and_show_booking_status() OWNER TO postgres;

--
-- Name: update_schedule_tickets(integer, integer); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.update_schedule_tickets(IN p_schedule_id integer, IN p_ticket_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Update the schedule: increment TotalSeatsBooked and adjust waitingtickets
    UPDATE schedule
    SET TotalSeatsBooked = CASE 
                               WHEN TotalSeatsBooked <= 55 THEN TotalSeatsBooked + 1
                               ELSE TotalSeatsBooked
                           END,
		Status = CASE	
					WHEN TotalSeatsBooked >= 49 AND TotalSeatsBooked <= 54 THEN 'FULL'
                    ELSE 'ON TIME'
                           END,
						   
        waitingtickets = CASE
                            WHEN TotalSeatsBooked >= 50 AND TotalSeatsBooked <= 55 THEN TotalSeatsBooked - 50
                            ELSE waitingtickets
                         END
    WHERE schedule_id = p_schedule_id;

    -- Update the booking status of the ticket based on the updated TotalSeatsBooked
    UPDATE ticket
    SET BookingStatus = CASE 
                            WHEN (SELECT TotalSeatsBooked FROM schedule WHERE schedule_id = ticket.schedule_id) <= 50 THEN 'CONFIRMED'
                            WHEN (SELECT TotalSeatsBooked FROM schedule WHERE schedule_id = ticket.schedule_id) BETWEEN 51 AND 55 THEN 'WAITING'
                            WHEN (SELECT TotalSeatsBooked FROM schedule WHERE schedule_id = ticket.schedule_id) > 55 THEN 'FULL'
                            WHEN (SELECT CURRENT_DATE - bookingopendate FROM schedule WHERE schedule_id = ticket.schedule_id) >= 7 THEN 'CLOSED'
                            ELSE BookingStatus 
-- 							Since a ticket is added as soon as executed you don't see the change
                        END
    FROM schedule -- Necessary for referencing schedule in the subquery
    WHERE ticket_id = p_ticket_id AND ticket.schedule_id = p_schedule_id;
END;
$$;


ALTER PROCEDURE public.update_schedule_tickets(IN p_schedule_id integer, IN p_ticket_id integer) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    address_id integer NOT NULL,
    street character varying(50),
    city character varying(50),
    province character varying(50),
    postalcode character varying(50),
    country character varying(50)
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employee (
    employee_id integer NOT NULL,
    name character varying(50),
    role character varying(50),
    department character varying(50),
    hiredate date,
    salary money,
    birthdate date,
    phone character varying(50),
    address_id integer,
    station_id character varying(7)
);


ALTER TABLE public.employee OWNER TO postgres;

--
-- Name: employee_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employee_employee_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employee_employee_id_seq OWNER TO postgres;

--
-- Name: employee_employee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employee_employee_id_seq OWNED BY public.employee.employee_id;


--
-- Name: maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maintenance_id_seq
    START WITH 10000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maintenance_id_seq OWNER TO postgres;

--
-- Name: maintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maintenance (
    maintenance_id integer DEFAULT nextval('public.maintenance_id_seq'::regclass) NOT NULL,
    details text,
    duration character varying(10),
    worktype character varying(28),
    performedby character varying(50),
    companyphone character varying(50),
    companyemail character varying(50),
    address_id integer
);


ALTER TABLE public.maintenance OWNER TO postgres;

--
-- Name: passenger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.passenger (
    passenger_id integer NOT NULL,
    name character varying(50),
    birthdate date,
    gender character varying(50),
    phone character varying(50),
    email character varying(50),
    address_id integer
);


ALTER TABLE public.passenger OWNER TO postgres;

--
-- Name: passenger_passenger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.passenger_passenger_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.passenger_passenger_id_seq OWNER TO postgres;

--
-- Name: passenger_passenger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.passenger_passenger_id_seq OWNED BY public.passenger.passenger_id;


--
-- Name: route; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.route (
    route_id integer NOT NULL,
    distance character varying(10),
    duration character varying(6),
    notices text,
    departurestation character varying(6),
    destinationstation character varying(6)
);


ALTER TABLE public.route OWNER TO postgres;

--
-- Name: schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schedule (
    schedule_id integer NOT NULL,
    departuredate date,
    departuretime character varying(50),
    arrivaltime character varying(50),
    status character varying(10),
    bookingopendate date,
    bookingcloseddate date,
    maxtickets integer,
    totalseatsbooked integer,
    waitingtickets integer,
    train_id character varying(4),
    route_id integer
);


ALTER TABLE public.schedule OWNER TO postgres;

--
-- Name: station; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.station (
    station_id character varying(6) DEFAULT 'STA001'::character varying NOT NULL,
    stationname character varying(60),
    city character varying(50),
    amenities character varying(50),
    ifbarrierfree character varying(50),
    operationhours character varying(50),
    maxtrainnum integer
);


ALTER TABLE public.station OWNER TO postgres;

--
-- Name: station_train; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.station_train (
    stationtrain_id integer,
    stopnumber integer,
    stationarrivaltime time without time zone,
    stationdeparturetime time without time zone,
    train_id character varying(4),
    station_id character varying(7)
);


ALTER TABLE public.station_train OWNER TO postgres;

--
-- Name: ticket; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket (
    ticket_id integer NOT NULL,
    bookingdate date,
    seatnum integer,
    platformnum integer DEFAULT public.random_platform_num(),
    price numeric(7,2) DEFAULT 50.00,
    bookingstatus character varying(20),
    schedule_id integer,
    passenger_id integer,
    ticketnum integer
);


ALTER TABLE public.ticket OWNER TO postgres;

--
-- Name: train; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.train (
    train_id character varying(4) NOT NULL,
    trainname character varying(50),
    maxpassengers integer,
    maidenvoyage date,
    servicetype character varying(20)
);


ALTER TABLE public.train OWNER TO postgres;

--
-- Name: train_maintenance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.train_maintenance (
    trainmaintenance_id integer,
    issuedetails character varying(255),
    deadlinedate date,
    servicedate date,
    nextservicedate date,
    train_id character varying(4),
    maintenance_id integer
);


ALTER TABLE public.train_maintenance OWNER TO postgres;

--
-- Name: trainspecs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trainspecs (
    trainspecs_id integer,
    weightcap integer,
    axleload character varying(10),
    numberofcars integer,
    length character varying(10),
    maxspeed character varying(10),
    accelerationrate character varying(10),
    decelerationrate character varying(10),
    powertype character varying(8),
    tracktype character varying(25),
    energysource character varying(17),
    energyconsumption character varying(10),
    train_id character varying(4)
);


ALTER TABLE public.trainspecs OWNER TO postgres;

--
-- Name: employee employee_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee ALTER COLUMN employee_id SET DEFAULT nextval('public.employee_employee_id_seq'::regclass);


--
-- Name: passenger passenger_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passenger ALTER COLUMN passenger_id SET DEFAULT nextval('public.passenger_passenger_id_seq'::regclass);


--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (address_id, street, city, province, postalcode, country) FROM stdin;
\.
COPY public.address (address_id, street, city, province, postalcode, country) FROM '$$PATH$$/3682.dat';

--
-- Data for Name: employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employee (employee_id, name, role, department, hiredate, salary, birthdate, phone, address_id, station_id) FROM stdin;
\.
COPY public.employee (employee_id, name, role, department, hiredate, salary, birthdate, phone, address_id, station_id) FROM '$$PATH$$/3685.dat';

--
-- Data for Name: maintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maintenance (maintenance_id, details, duration, worktype, performedby, companyphone, companyemail, address_id) FROM stdin;
\.
COPY public.maintenance (maintenance_id, details, duration, worktype, performedby, companyphone, companyemail, address_id) FROM '$$PATH$$/3688.dat';

--
-- Data for Name: passenger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.passenger (passenger_id, name, birthdate, gender, phone, email, address_id) FROM stdin;
\.
COPY public.passenger (passenger_id, name, birthdate, gender, phone, email, address_id) FROM '$$PATH$$/3694.dat';

--
-- Data for Name: route; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.route (route_id, distance, duration, notices, departurestation, destinationstation) FROM stdin;
\.
COPY public.route (route_id, distance, duration, notices, departurestation, destinationstation) FROM '$$PATH$$/3692.dat';

--
-- Data for Name: schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schedule (schedule_id, departuredate, departuretime, arrivaltime, status, bookingopendate, bookingcloseddate, maxtickets, totalseatsbooked, waitingtickets, train_id, route_id) FROM stdin;
\.
COPY public.schedule (schedule_id, departuredate, departuretime, arrivaltime, status, bookingopendate, bookingcloseddate, maxtickets, totalseatsbooked, waitingtickets, train_id, route_id) FROM '$$PATH$$/3695.dat';

--
-- Data for Name: station; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.station (station_id, stationname, city, amenities, ifbarrierfree, operationhours, maxtrainnum) FROM stdin;
\.
COPY public.station (station_id, stationname, city, amenities, ifbarrierfree, operationhours, maxtrainnum) FROM '$$PATH$$/3683.dat';

--
-- Data for Name: station_train; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.station_train (stationtrain_id, stopnumber, stationarrivaltime, stationdeparturetime, train_id, station_id) FROM stdin;
\.
COPY public.station_train (stationtrain_id, stopnumber, stationarrivaltime, stationdeparturetime, train_id, station_id) FROM '$$PATH$$/3691.dat';

--
-- Data for Name: ticket; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket (ticket_id, bookingdate, seatnum, platformnum, price, bookingstatus, schedule_id, passenger_id, ticketnum) FROM stdin;
\.
COPY public.ticket (ticket_id, bookingdate, seatnum, platformnum, price, bookingstatus, schedule_id, passenger_id, ticketnum) FROM '$$PATH$$/3696.dat';

--
-- Data for Name: train; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.train (train_id, trainname, maxpassengers, maidenvoyage, servicetype) FROM stdin;
\.
COPY public.train (train_id, trainname, maxpassengers, maidenvoyage, servicetype) FROM '$$PATH$$/3686.dat';

--
-- Data for Name: train_maintenance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.train_maintenance (trainmaintenance_id, issuedetails, deadlinedate, servicedate, nextservicedate, train_id, maintenance_id) FROM stdin;
\.
COPY public.train_maintenance (trainmaintenance_id, issuedetails, deadlinedate, servicedate, nextservicedate, train_id, maintenance_id) FROM '$$PATH$$/3690.dat';

--
-- Data for Name: trainspecs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trainspecs (trainspecs_id, weightcap, axleload, numberofcars, length, maxspeed, accelerationrate, decelerationrate, powertype, tracktype, energysource, energyconsumption, train_id) FROM stdin;
\.
COPY public.trainspecs (trainspecs_id, weightcap, axleload, numberofcars, length, maxspeed, accelerationrate, decelerationrate, powertype, tracktype, energysource, energyconsumption, train_id) FROM '$$PATH$$/3689.dat';

--
-- Name: employee_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employee_employee_id_seq', 1, false);


--
-- Name: maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maintenance_id_seq', 10000, false);


--
-- Name: passenger_passenger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.passenger_passenger_id_seq', 1, false);


--
-- Name: address address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.address
    ADD CONSTRAINT address_pkey PRIMARY KEY (address_id);


--
-- Name: employee employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_pkey PRIMARY KEY (employee_id);


--
-- Name: maintenance maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance
    ADD CONSTRAINT maintenance_pkey PRIMARY KEY (maintenance_id);


--
-- Name: passenger passenger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passenger
    ADD CONSTRAINT passenger_pkey PRIMARY KEY (passenger_id);


--
-- Name: route route_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_pkey PRIMARY KEY (route_id);


--
-- Name: schedule schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_pkey PRIMARY KEY (schedule_id);


--
-- Name: station station_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.station
    ADD CONSTRAINT station_pkey PRIMARY KEY (station_id);


--
-- Name: ticket ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_pkey PRIMARY KEY (ticket_id);


--
-- Name: train train_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.train
    ADD CONSTRAINT train_pkey PRIMARY KEY (train_id);


--
-- Name: employee employee_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: employee employee_station_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employee
    ADD CONSTRAINT employee_station_id_fkey FOREIGN KEY (station_id) REFERENCES public.station(station_id);


--
-- Name: maintenance fk_address; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance
    ADD CONSTRAINT fk_address FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: passenger passenger_address_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.passenger
    ADD CONSTRAINT passenger_address_id_fkey FOREIGN KEY (address_id) REFERENCES public.address(address_id);


--
-- Name: route route_departurestation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_departurestation_fkey FOREIGN KEY (departurestation) REFERENCES public.station(station_id);


--
-- Name: route route_destinationstation_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.route
    ADD CONSTRAINT route_destinationstation_fkey FOREIGN KEY (destinationstation) REFERENCES public.station(station_id);


--
-- Name: schedule schedule_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.route(route_id);


--
-- Name: schedule schedule_train_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schedule
    ADD CONSTRAINT schedule_train_id_fkey FOREIGN KEY (train_id) REFERENCES public.train(train_id);


--
-- Name: ticket ticket_passenger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_passenger_id_fkey FOREIGN KEY (passenger_id) REFERENCES public.passenger(passenger_id);


--
-- Name: ticket ticket_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket
    ADD CONSTRAINT ticket_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.schedule(schedule_id);


--
-- Name: train_maintenance train_maintenance_maintenance_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.train_maintenance
    ADD CONSTRAINT train_maintenance_maintenance_id_fkey FOREIGN KEY (maintenance_id) REFERENCES public.maintenance(maintenance_id);


--
-- Name: train_maintenance train_maintenance_train_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.train_maintenance
    ADD CONSTRAINT train_maintenance_train_id_fkey FOREIGN KEY (train_id) REFERENCES public.train(train_id);


--
-- Name: trainspecs trainspecs_train_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trainspecs
    ADD CONSTRAINT trainspecs_train_id_fkey FOREIGN KEY (train_id) REFERENCES public.train(train_id);


--
-- PostgreSQL database dump complete
--

